import React,{ Component } from 'react'
import ReactDOM from 'react-dom'

console.log(process.env)

ReactDOM.render(
    <div>hello,world</div>,
    document.querySelector('#root')
)